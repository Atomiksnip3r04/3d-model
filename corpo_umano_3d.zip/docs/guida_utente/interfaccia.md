# Visualizzatore 3D del Corpo Umano - Guida all'Interfaccia

## Interfaccia Utente

L'interfaccia del Visualizzatore 3D del Corpo Umano è stata progettata per essere intuitiva e facile da usare. È suddivisa in tre aree principali:

1. **Area di Visualizzazione**: La parte centrale dell'interfaccia dove viene mostrato il modello 3D.
2. **Pannello dei Filtri**: Situato sulla sinistra, permette di controllare quali parti del modello sono visibili.
3. **Pannello Informativo**: Situato sulla destra, mostra informazioni dettagliate sulla parte selezionata.

## Controlli di Navigazione

### Rotazione del Modello
- **Mouse**: Clicca e trascina nell'area di visualizzazione per ruotare il modello.
- **Pulsanti di Vista**: Utilizza i pulsanti "Vista Frontale", "Vista Posteriore", "Vista Laterale" e "Vista dall'Alto" per passare rapidamente a viste predefinite.

### Zoom
- **Rotellina del Mouse**: Scorri la rotellina per ingrandire o ridurre il modello.
- **Pulsanti di Zoom**: Utilizza i pulsanti "Zoom In" e "Zoom Out" per controllare il livello di zoom.

### Reset della Vista
- Utilizza il pulsante "Reset Vista" per tornare alla vista predefinita.

## Filtri dei Sistemi Anatomici

Puoi mostrare o nascondere specifici sistemi anatomici utilizzando le caselle di controllo nel pannello dei filtri:

- **Sistema Scheletrico**: Mostra/nasconde ossa e strutture di supporto.
- **Sistema Muscolare**: Mostra/nasconde i muscoli.
- **Sistema Nervoso**: Mostra/nasconde cervello, midollo spinale e nervi.
- **Sistema Cardiovascolare**: Mostra/nasconde cuore e vasi sanguigni.
- **Sistema Respiratorio**: Mostra/nasconde polmoni e vie respiratorie.
- **Sistema Digerente**: Mostra/nasconde organi digestivi.

## Filtri delle Regioni del Corpo

Puoi anche filtrare il modello per regioni specifiche del corpo:

- **Testa**: Mostra/nasconde le strutture della testa.
- **Torso**: Mostra/nasconde le strutture del torso.
- **Braccia**: Mostra/nasconde le strutture delle braccia.
- **Gambe**: Mostra/nasconde le strutture delle gambe.

## Effetti Visivi

### Modalità Wireframe
- Attiva la casella "Wireframe" per visualizzare il modello in modalità wireframe, che mostra la struttura a rete del modello.

### Trasparenza
- Attiva la casella "Trasparenza" per rendere il modello semi-trasparente.
- Utilizza lo slider per regolare il livello di trasparenza da 0% (completamente trasparente) a 100% (completamente opaco).

## Selezione e Informazioni

- Clicca su qualsiasi parte del modello per selezionarla.
- Le informazioni sulla parte selezionata verranno mostrate nel pannello informativo sulla destra.
- Le informazioni includono il nome della parte, il sistema anatomico a cui appartiene e una breve descrizione.
