// Modello placeholder per il corpo umano
function createHumanBodyModel() {
    const bodyGroup = new THREE.Group();
    
    // Testa
    const headGeometry = new THREE.SphereGeometry(0.25, 32, 32);
    const headMaterial = new THREE.MeshLambertMaterial({ color: 0xf0d0c0 });
    const head = new THREE.Mesh(headGeometry, headMaterial);
    head.position.y = 1.7;
    head.userData = { type: 'skeletal', region: 'head', name: 'Testa' };
    bodyGroup.add(head);
    
    // Torso
    const torsoGeometry = new THREE.CylinderGeometry(0.3, 0.25, 0.6, 32);
    const torsoMaterial = new THREE.MeshLambertMaterial({ color: 0xf0d0c0 });
    const torso = new THREE.Mesh(torsoGeometry, torsoMaterial);
    torso.position.y = 1.25;
    torso.userData = { type: 'muscular', region: 'torso', name: 'Torso' };
    bodyGroup.add(torso);
    
    // Bacino
    const pelvisGeometry = new THREE.CylinderGeometry(0.25, 0.2, 0.3, 32);
    const pelvisMaterial = new THREE.MeshLambertMaterial({ color: 0xf0d0c0 });
    const pelvis = new THREE.Mesh(pelvisGeometry, pelvisMaterial);
    pelvis.position.y = 0.9;
    pelvis.userData = { type: 'skeletal', region: 'torso', name: 'Bacino' };
    bodyGroup.add(pelvis);
    
    // Braccia
    const armGeometry = new THREE.CylinderGeometry(0.08, 0.06, 0.5, 32);
    const armMaterial = new THREE.MeshLambertMaterial({ color: 0xf0d0c0 });
    
    const leftArm = new THREE.Mesh(armGeometry, armMaterial);
    leftArm.position.set(-0.4, 1.25, 0);
    leftArm.rotation.z = Math.PI / 6;
    leftArm.userData = { type: 'muscular', region: 'arms', name: 'Braccio Sinistro' };
    bodyGroup.add(leftArm);
    
    const rightArm = new THREE.Mesh(armGeometry, armMaterial);
    rightArm.position.set(0.4, 1.25, 0);
    rightArm.rotation.z = -Math.PI / 6;
    rightArm.userData = { type: 'muscular', region: 'arms', name: 'Braccio Destro' };
    bodyGroup.add(rightArm);
    
    // Avambracci
    const forearmGeometry = new THREE.CylinderGeometry(0.06, 0.05, 0.5, 32);
    const forearmMaterial = new THREE.MeshLambertMaterial({ color: 0xf0d0c0 });
    
    const leftForearm = new THREE.Mesh(forearmGeometry, forearmMaterial);
    leftForearm.position.set(-0.6, 1.0, 0);
    leftForearm.rotation.z = Math.PI / 3;
    leftForearm.userData = { type: 'muscular', region: 'arms', name: 'Avambraccio Sinistro' };
    bodyGroup.add(leftForearm);
    
    const rightForearm = new THREE.Mesh(forearmGeometry, forearmMaterial);
    rightForearm.position.set(0.6, 1.0, 0);
    rightForearm.rotation.z = -Math.PI / 3;
    rightForearm.userData = { type: 'muscular', region: 'arms', name: 'Avambraccio Destro' };
    bodyGroup.add(rightForearm);
    
    // Gambe
    const legGeometry = new THREE.CylinderGeometry(0.1, 0.08, 0.5, 32);
    const legMaterial = new THREE.MeshLambertMaterial({ color: 0xf0d0c0 });
    
    const leftLeg = new THREE.Mesh(legGeometry, legMaterial);
    leftLeg.position.set(-0.15, 0.65, 0);
    leftLeg.userData = { type: 'muscular', region: 'legs', name: 'Coscia Sinistra' };
    bodyGroup.add(leftLeg);
    
    const rightLeg = new THREE.Mesh(legGeometry, legMaterial);
    rightLeg.position.set(0.15, 0.65, 0);
    rightLeg.userData = { type: 'muscular', region: 'legs', name: 'Coscia Destra' };
    bodyGroup.add(rightLeg);
    
    // Polpacci
    const calfGeometry = new THREE.CylinderGeometry(0.08, 0.06, 0.5, 32);
    const calfMaterial = new THREE.MeshLambertMaterial({ color: 0xf0d0c0 });
    
    const leftCalf = new THREE.Mesh(calfGeometry, calfMaterial);
    leftCalf.position.set(-0.15, 0.2, 0);
    leftCalf.userData = { type: 'muscular', region: 'legs', name: 'Polpaccio Sinistro' };
    bodyGroup.add(leftCalf);
    
    const rightCalf = new THREE.Mesh(calfGeometry, calfMaterial);
    rightCalf.position.set(0.15, 0.2, 0);
    rightCalf.userData = { type: 'muscular', region: 'legs', name: 'Polpaccio Destro' };
    bodyGroup.add(rightCalf);
    
    return bodyGroup;
}

// Modello del sistema scheletrico
function createSkeletalSystem() {
    const skeletonGroup = new THREE.Group();
    
    // Cranio
    const skullGeometry = new THREE.SphereGeometry(0.22, 32, 32);
    const skullMaterial = new THREE.MeshLambertMaterial({ color: 0xf0f0f0 });
    const skull = new THREE.Mesh(skullGeometry, skullMaterial);
    skull.position.y = 1.7;
    skull.userData = { type: 'skeletal', region: 'head', name: 'Cranio' };
    skeletonGroup.add(skull);
    
    // Colonna vertebrale
    const spineGeometry = new THREE.CylinderGeometry(0.05, 0.05, 0.8, 16);
    const spineMaterial = new THREE.MeshLambertMaterial({ color: 0xf0f0f0 });
    const spine = new THREE.Mesh(spineGeometry, spineMaterial);
    spine.position.y = 1.2;
    spine.userData = { type: 'skeletal', region: 'torso', name: 'Colonna Vertebrale' };
    skeletonGroup.add(spine);
    
    // Gabbia toracica
    const ribsGeometry = new THREE.SphereGeometry(0.25, 32, 16, 0, Math.PI * 2, 0, Math.PI / 2);
    const ribsMaterial = new THREE.MeshLambertMaterial({ color: 0xf0f0f0, wireframe: true });
    const ribs = new THREE.Mesh(ribsGeometry, ribsMaterial);
    ribs.position.y = 1.3;
    ribs.scale.set(1.2, 0.8, 0.8);
    ribs.userData = { type: 'skeletal', region: 'torso', name: 'Gabbia Toracica' };
    skeletonGroup.add(ribs);
    
    // Bacino osseo
    const pelvisGeometry = new THREE.RingGeometry(0.15, 0.25, 32);
    const pelvisMaterial = new THREE.MeshLambertMaterial({ color: 0xf0f0f0 });
    const pelvis = new THREE.Mesh(pelvisGeometry, pelvisMaterial);
    pelvis.position.y = 0.9;
    pelvis.rotation.x = Math.PI / 2;
    pelvis.userData = { type: 'skeletal', region: 'torso', name: 'Bacino' };
    skeletonGroup.add(pelvis);
    
    // Ossa delle braccia
    const armBoneGeometry = new THREE.CylinderGeometry(0.05, 0.04, 0.4, 16);
    const armBoneMaterial = new THREE.MeshLambertMaterial({ color: 0xf0f0f0 });
    
    const leftArmBone = new THREE.Mesh(armBoneGeometry, armBoneMaterial);
    leftArmBone.position.set(-0.4, 1.25, 0);
    leftArmBone.rotation.z = Math.PI / 6;
    leftArmBone.userData = { type: 'skeletal', region: 'arms', name: 'Omero Sinistro' };
    skeletonGroup.add(leftArmBone);
    
    const rightArmBone = new THREE.Mesh(armBoneGeometry, armBoneMaterial);
    rightArmBone.position.set(0.4, 1.25, 0);
    rightArmBone.rotation.z = -Math.PI / 6;
    rightArmBone.userData = { type: 'skeletal', region: 'arms', name: 'Omero Destro' };
    skeletonGroup.add(rightArmBone);
    
    // Ossa degli avambracci
    const forearmBoneGeometry = new THREE.CylinderGeometry(0.04, 0.03, 0.4, 16);
    const forearmBoneMaterial = new THREE.MeshLambertMaterial({ color: 0xf0f0f0 });
    
    const leftForearmBone = new THREE.Mesh(forearmBoneGeometry, forearmBoneMaterial);
    leftForearmBone.position.set(-0.6, 1.0, 0);
    leftForearmBone.rotation.z = Math.PI / 3;
    leftForearmBone.userData = { type: 'skeletal', region: 'arms', name: 'Radio e Ulna Sinistri' };
    skeletonGroup.add(leftForearmBone);
    
    const rightForearmBone = new THREE.Mesh(forearmBoneGeometry, forearmBoneMaterial);
    rightForearmBone.position.set(0.6, 1.0, 0);
    rightForearmBone.rotation.z = -Math.PI / 3;
    rightForearmBone.userData = { type: 'skeletal', region: 'arms', name: 'Radio e Ulna Destri' };
    skeletonGroup.add(rightForearmBone);
    
    // Ossa delle gambe
    const legBoneGeometry = new THREE.CylinderGeometry(0.06, 0.05, 0.4, 16);
    const legBoneMaterial = new THREE.MeshLambertMaterial({ color: 0xf0f0f0 });
    
    const leftLegBone = new THREE.Mesh(legBoneGeometry, legBoneMaterial);
    leftLegBone.position.set(-0.15, 0.65, 0);
    leftLegBone.userData = { type: 'skeletal', region: 'legs', name: 'Femore Sinistro' };
    skeletonGroup.add(leftLegBone);
    
    const rightLegBone = new THREE.Mesh(legBoneGeometry, legBoneMaterial);
    rightLegBone.position.set(0.15, 0.65, 0);
    rightLegBone.userData = { type: 'skeletal', region: 'legs', name: 'Femore Destro' };
    skeletonGroup.add(rightLegBone);
    
    // Ossa dei polpacci
    const calfBoneGeometry = new THREE.CylinderGeometry(0.05, 0.04, 0.4, 16);
    const calfBoneMaterial = new THREE.MeshLambertMaterial({ color: 0xf0f0f0 });
    
    const leftCalfBone = new THREE.Mesh(calfBoneGeometry, calfBoneMaterial);
    leftCalfBone.position.set(-0.15, 0.2, 0);
    leftCalfBone.userData = { type: 'skeletal', region: 'legs', name: 'Tibia e Perone Sinistri' };
    skeletonGroup.add(leftCalfBone);
    
    const rightCalfBone = new THREE.Mesh(calfBoneGeometry, calfBoneMaterial);
    rightCalfBone.position.set(0.15, 0.2, 0);
    rightCalfBone.userData = { type: 'skeletal', region: 'legs', name: 'Tibia e Perone Destri' };
    skeletonGroup.add(rightCalfBone);
    
    return skeletonGroup;
}

// Modello del sistema muscolare
function createMuscularSystem() {
    const muscleGroup = new THREE.Group();
    
    // Muscoli del collo
    const neckMuscleGeometry = new THREE.CylinderGeometry(0.1, 0.12, 0.15, 32);
    const muscleMaterial = new THREE.MeshLambertMaterial({ color: 0xe74c3c });
    const neckMuscle = new THREE.Mesh(neckMuscleGeometry, muscleMaterial);
    neckMuscle.position.y = 1.6;
    neckMuscle.userData = { type: 'muscular', region: 'head', name: 'Muscoli del Collo' };
    muscleGroup.add(neckMuscle);
    
    // Muscoli pettorali
    const pectoralGeometry = new THREE.SphereGeometry(0.2, 32, 16, 0, Math.PI, 0, Math.PI / 2);
    const pectoralMuscle = new THREE.Mesh(pectoralGeometry, muscleMaterial);
    pectoralMuscle.position.y = 1.35;
    pectoralMuscle.position.z = 0.1;
    pectoralMuscle.rotation.x = Math.PI;
    pectoralMuscle.scale.set(1.5, 0.7, 0.5);
    pectoralMuscle.userData = { type: 'muscular', region: 'torso', name: 'Muscoli Pettorali' };
    muscleGroup.add(pectoralMuscle);
    
    // Muscoli addominali
    const abdominalGeometry = new THREE.BoxGeometry(0.3, 0.4, 0.1);
    const abdominalMuscle = new THREE.Mesh(abdominalGeometry, muscleMaterial);
    abdominalMuscle.position.set(0, 1.1, 0.1);
    abdominalMuscle.userData = { type: 'muscular', region: 'torso', name: 'Muscoli Addominali' };
    muscleGroup.add(abdominalMuscle);
    
    // Muscoli dorsali
    const backMuscleGeometry = new THREE.BoxGeometry(0.4, 0.5, 0.1);
    const backMuscle = new THREE.Mesh(backMuscleGeometry, muscleMaterial);
    backMuscle.position.set(0, 1.2, -0.1);
    backMuscle.userData = { type: 'muscular', region: 'torso', name: 'Muscoli Dorsali' };
    muscleGroup.add(backMuscle);
    
    // Muscoli delle braccia (bicipiti)
    const bicepGeometry = new THREE.SphereGeometry(0.08, 32, 16);
    
    const leftBicep = new THREE.Mesh(bicepGeometry, muscleMaterial);
    leftBicep.position.set(-0.4, 1.25, 0.05);
    leftBicep.scale.set(1, 1, 0.8);
    leftBicep.userData = { type: 'muscular', region: 'arms', name: 'Bicipite Sinistro' };
    muscleGroup.add(leftBicep);
    
    const rightBicep = new THREE.Mesh(bicepGeometry, muscleMaterial);
    rightBicep.position.set(0.4, 1.25, 0.05);
    rightBicep.scale.set(1, 1, 0.8);
    rightBicep.userData = { type: 'muscular', region: 'arms', name: 'Bicipite Destro' };
    muscleGroup.add(rightBicep);
    
    // Muscoli delle cosce (quadricipiti)
    const thighMuscleGeometry = new THREE.CylinderGeometry(0.11, 0.09, 0.4, 32);
    
    const leftThighMuscle = new THREE.Mesh(thighMuscleGeometry, muscleMaterial);
    leftThighMuscle.position.set(-0.15, 0.65, 0.02);
    leftThighMuscle.userData = { type: 'muscular', region: 'legs', name: 'Quadricipite Sinistro' };
    muscleGroup.add(leftThighMuscle);
    
    const rightThighMuscle = new THREE.Mesh(thighMuscleGeometry, muscleMaterial);
    rightThighMuscle.position.set(0.15, 0.65, 0.02);
    rightThighMuscle.userData = { type: 'muscular', region: 'legs', name: 'Quadricipite Destro' };
    muscleGroup.add(rightThighMuscle);
    
    // Muscoli dei polpacci
    const calfMuscleGeometry = new THREE.CylinderGeometry(0.09, 0.06, 0.4, 32);
    
    const leftCalfMuscle = new THREE.Mesh(calfMuscleGeometry, muscleMaterial);
    leftCalfMuscle.position.set(-0.15, 0.2, 0.02);
    leftCalfMuscle.userData = { type: 'muscular', region: 'legs', name: 'Polpaccio Sinistro' };
    muscleGroup.add(leftCalfMuscle);
    
    const rightCalfMuscle = new THREE.Mesh(calfMuscleGeometry, muscleMaterial);
    rightCalfMuscle.position.set(0.15, 0.2, 0.02);
    rightCalfMuscle.userData = { type: 'muscular', region: 'legs', name: 'Polpaccio Destro' };
    muscleGroup.add(rightCalfMuscle);
    
    return muscleGroup;
}

// Modello del sistema nervoso
function createNervousSystem() {
    const nervousGroup = new THREE.Group();
    
    // Cervello
    const brainGeometry = new THREE.SphereGeometry(0.2, 32, 32);
    const brainMaterial = new THREE.MeshLambertMaterial({ color: 0xf1c40f });
    const brain = new THREE.Mesh(brainGeometry, brainMaterial);
    brain.position.set(0, 1.75, 0);
    brain.scale.set(0.9, 0.8, 0.9);
    brain.userData = { type: 'nervous', region: 'head', name: 'Cervello' };
    nervousGroup.add(brain);
    
    // Midollo spinale
    const spinalCordGeometry = new THREE.CylinderGeometry(0.02, 0.02, 0.9, 16);
    const nerveMaterial = new THREE.MeshLambertMaterial({ color: 0xf1c40f });
    const spinalCord = new THREE.Mesh(spinalCordGeometry, nerveMaterial);
    spinalCord.position.y = 1.2;
    spinalCord.userData = { type: 'nervous', region: 'torso', name: 'Midollo Spinale' };
    nervousGroup.add(spinalCord);
    
    // Nervi principali (semplificati)
    const nerveGeometry = new THREE.CylinderGeometry(0.01, 0.01, 0.4, 8);
    
    // Nervi del braccio sinistro
    const leftArmNerve = new THREE.Mesh(nerveGeometry, nerveMaterial);
    leftArmNerve.position.set(-0.4, 1.25, 0);
    leftArmNerve.rotation.z = Math.PI / 6;
    leftArmNerve.userData = { type: 'nervous', region: 'arms', name: 'Nervo Brachiale Sinistro' };
    nervousGroup.add(leftArmNerve);
    
    // Nervi del braccio destro
    const rightArmNerve = new THREE.Mesh(nerveGeometry, nerveMaterial);
    rightArmNerve.position.set(0.4, 1.25, 0);
    rightArmNerve.rotation.z = -Math.PI / 6;
    rightArmNerve.userData = { type: 'nervous', region: 'arms', name: 'Nervo Brachiale Destro' };
    nervousGroup.add(rightArmNerve);
    
    // Nervi della gamba sinistra
    const leftLegNerve = new THREE.Mesh(nerveGeometry, nerveMaterial);
    leftLegNerve.position.set(-0.15, 0.65, 0);
    leftLegNerve.userData = { type: 'nervous', region: 'legs', name: 'Nervo Sciatico Sinistro' };
    nervousGroup.add(leftLegNerve);
    
    // Nervi della gamba destra
    const rightLegNerve = new THREE.Mesh(nerveGeometry, nerveMaterial);
    rightLegNerve.position.set(0.15, 0.65, 0);
    rightLegNerve.userData = { type: 'nervous', region: 'legs', name: 'Nervo Sciatico Destro' };
    nervousGroup.add(rightLegNerve);
    
    return nervousGroup;
}

// Modello del sistema cardiovascolare
function createCardiovascularSystem() {
    const cardiovascularGroup = new THREE.Group();
    
    // Cuore
    const heartGeometry = new THREE.SphereGeometry(0.1, 32, 32);
    const heartMaterial = new THREE.MeshLambertMaterial({ color: 0xe74c3c });
    const heart = new THREE.Mesh(heartGeometry, heartMaterial);
    heart.position.set(0.1, 1.3, 0.1);
    heart.userData = { type: 'cardiovascular', region: 'torso', name: 'Cuore' };
    cardiovascularGroup.add(heart);
    
    // Aorta
    const aortaGeometry = new THREE.TorusGeometry(0.05, 0.01, 16, 32, Math.PI);
    const vesselMaterial = new THREE.MeshLambertMaterial({ color: 0xe74c3c });
    const aorta = new THREE.Mesh(aortaGeometry, vesselMaterial);
    aorta.position.set(0.1, 1.35, 0.1);
    aorta.rotation.x = Math.PI / 2;
    aorta.userData = { type: 'cardiovascular', region: 'torso', name: 'Aorta' };
    cardiovascularGroup.add(aorta);
    
    // Vasi principali (semplificati)
    const vesselGeometry = new THREE.CylinderGeometry(0.01, 0.01, 0.5, 8);
    
    // Arterie del braccio sinistro
    const leftArmArtery = new THREE.Mesh(vesselGeometry, vesselMaterial);
    leftArmArtery.position.set(-0.4, 1.25, 0);
    leftArmArtery.rotation.z = Math.PI / 6;
    leftArmArtery.userData = { type: 'cardiovascular', region: 'arms', name: 'Arteria Brachiale Sinistra' };
    cardiovascularGroup.add(leftArmArtery);
    
    // Arterie del braccio destro
    const rightArmArtery = new THREE.Mesh(vesselGeometry, vesselMaterial);
    rightArmArtery.position.set(0.4, 1.25, 0);
    rightArmArtery.rotation.z = -Math.PI / 6;
    rightArmArtery.userData = { type: 'cardiovascular', region: 'arms', name: 'Arteria Brachiale Destra' };
    cardiovascularGroup.add(rightArmArtery);
    
    // Arterie della gamba sinistra
    const leftLegArtery = new THREE.Mesh(vesselGeometry, vesselMaterial);
    leftLegArtery.position.set(-0.15, 0.65, 0);
    leftLegArtery.userData = { type: 'cardiovascular', region: 'legs', name: 'Arteria Femorale Sinistra' };
    cardiovascularGroup.add(leftLegArtery);
    
    // Arterie della gamba destra
    const rightLegArtery = new THREE.Mesh(vesselGeometry, vesselMaterial);
    rightLegArtery.position.set(0.15, 0.65, 0);
    rightLegArtery.userData = { type: 'cardiovascular', region: 'legs', name: 'Arteria Femorale Destra' };
    cardiovascularGroup.add(rightLegArtery);
    
    return cardiovascularGroup;
}

// Modello del sistema respiratorio
function createRespiratorySystem() {
    const respiratoryGroup = new THREE.Group();
    
    // Polmoni
    const lungsGeometry = new THREE.SphereGeometry(0.12, 32, 32);
    const lungsMaterial = new THREE.MeshLambertMaterial({ color: 0x3498db });
    
    const leftLung = new THREE.Mesh(lungsGeometry, lungsMaterial);
    leftLung.position.set(-0.15, 1.35, 0.05);
    leftLung.scale.set(0.7, 1, 0.7);
    leftLung.userData = { type: 'respiratory', region: 'torso', name: 'Polmone Sinistro' };
    respiratoryGroup.add(leftLung);
    
    const rightLung = new THREE.Mesh(lungsGeometry, lungsMaterial);
    rightLung.position.set(0.15, 1.35, 0.05);
    rightLung.scale.set(0.7, 1, 0.7);
    rightLung.userData = { type: 'respiratory', region: 'torso', name: 'Polmone Destro' };
    respiratoryGroup.add(rightLung);
    
    // Trachea
    const tracheaGeometry = new THREE.CylinderGeometry(0.03, 0.03, 0.2, 16);
    const tracheaMaterial = new THREE.MeshLambertMaterial({ color: 0x3498db });
    const trachea = new THREE.Mesh(tracheaGeometry, tracheaMaterial);
    trachea.position.set(0, 1.5, 0.05);
    trachea.userData = { type: 'respiratory', region: 'torso', name: 'Trachea' };
    respiratoryGroup.add(trachea);
    
    // Bronchi principali
    const bronchusGeometry = new THREE.CylinderGeometry(0.02, 0.02, 0.1, 16);
    
    const leftBronchus = new THREE.Mesh(bronchusGeometry, tracheaMaterial);
    leftBronchus.position.set(-0.05, 1.4, 0.05);
    leftBronchus.rotation.z = Math.PI / 4;
    leftBronchus.userData = { type: 'respiratory', region: 'torso', name: 'Bronco Principale Sinistro' };
    respiratoryGroup.add(leftBronchus);
    
    const rightBronchus = new THREE.Mesh(bronchusGeometry, tracheaMaterial);
    rightBronchus.position.set(0.05, 1.4, 0.05);
    rightBronchus.rotation.z = -Math.PI / 4;
    rightBronchus.userData = { type: 'respiratory', region: 'torso', name: 'Bronco Principale Destro' };
    respiratoryGroup.add(rightBronchus);
    
    return respiratoryGroup;
}

// Modello del sistema digerente
function createDigestiveSystem() {
    const digestiveGroup = new THREE.Group();
    
    // Esofago
    const esophagusGeometry = new THREE.CylinderGeometry(0.02, 0.02, 0.3, 16);
    const digestiveMaterial = new THREE.MeshLambertMaterial({ color: 0x9b59b6 });
    const esophagus = new THREE.Mesh(esophagusGeometry, digestiveMaterial);
    esophagus.position.set(0, 1.4, 0);
    esophagus.userData = { type: 'digestive', region: 'torso', name: 'Esofago' };
    digestiveGroup.add(esophagus);
    
    // Stomaco
    const stomachGeometry = new THREE.SphereGeometry(0.12, 32, 32);
    const stomach = new THREE.Mesh(stomachGeometry, digestiveMaterial);
    stomach.position.set(0, 1.1, 0.1);
    stomach.scale.set(0.8, 1, 0.6);
    stomach.userData = { type: 'digestive', region: 'torso', name: 'Stomaco' };
    digestiveGroup.add(stomach);
    
    // Intestino
    const intestineGeometry = new THREE.TorusKnotGeometry(0.1, 0.03, 64, 8, 2, 3);
    const intestine = new THREE.Mesh(intestineGeometry, digestiveMaterial);
    intestine.position.set(0, 0.9, 0);
    intestine.scale.set(0.8, 0.8, 0.8);
    intestine.userData = { type: 'digestive', region: 'torso', name: 'Intestino' };
    digestiveGroup.add(intestine);
    
    // Fegato
    const liverGeometry = new THREE.SphereGeometry(0.1, 32, 32);
    const liver = new THREE.Mesh(liverGeometry, digestiveMaterial);
    liver.position.set(-0.1, 1.2, 0.1);
    liver.scale.set(1.2, 0.8, 0.7);
    liver.userData = { type: 'digestive', region: 'torso', name: 'Fegato' };
    digestiveGroup.add(liver);
    
    return digestiveGroup;
}

// Funzione per creare il modello completo
function createCompleteHumanModel() {
    const humanModel = new THREE.Group();
    
    // Aggiungi il corpo base
    const body = createHumanBodyModel();
    body.visible = false; // Nascondiamo il corpo base e mostriamo solo i sistemi
    humanModel.add(body);
    
    // Aggiungi i vari sistemi
    const skeletalSystem = createSkeletalSystem();
    skeletalSystem.name = 'skeletal-system';
    humanModel.add(skeletalSystem);
    
    const muscularSystem = createMuscularSystem();
    muscularSystem.name = 'muscular-system';
    humanModel.add(muscularSystem);
    
    const nervousSystem = createNervousSystem();
    nervousSystem.name = 'nervous-system';
    humanModel.add(nervousSystem);
    
    const cardiovascularSystem = createCardiovascularSystem();
    cardiovascularSystem.name = 'cardiovascular-system';
    humanModel.add(cardiovascularSystem);
    
    const respiratorySystem = createRespiratorySystem();
    respiratorySystem.name = 'respiratory-system';
    humanModel.add(respiratorySystem);
    
    const digestiveSystem = createDigestiveSystem();
    digestiveSystem.name = 'digestive-system';
    humanModel.add(digestiveSystem);
    
    return humanModel;
}
