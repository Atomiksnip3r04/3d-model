// Variabili globali
let scene, camera, renderer, controls, stats;
let model, mixer;
let clock = new THREE.Clock();
let gui, guiParams;
let raycaster, mouse;
let selectedObject = null;

// Configurazione iniziale
const config = {
    modelPath: 'models/human_anatomy.glb', // Questo sarà sostituito con il percorso reale al modello
    backgroundColor: 0xecf0f1,
    ambientLightColor: 0xffffff,
    ambientLightIntensity: 0.5,
    directionalLightColor: 0xffffff,
    directionalLightIntensity: 0.8,
    cameraPosition: { x: 0, y: 1.7, z: 3 }
};

// Sistemi anatomici e loro colori
const anatomySystems = {
    skeletal: { name: 'Sistema Scheletrico', color: 0xf0f0f0, visible: true },
    muscular: { name: 'Sistema Muscolare', color: 0xe74c3c, visible: true },
    nervous: { name: 'Sistema Nervoso', color: 0xf1c40f, visible: true },
    cardiovascular: { name: 'Sistema Cardiovascolare', color: 0xe74c3c, visible: true },
    respiratory: { name: 'Sistema Respiratorio', color: 0x3498db, visible: true },
    digestive: { name: 'Sistema Digerente', color: 0x9b59b6, visible: true }
};

// Regioni del corpo
const bodyRegions = {
    head: { name: 'Testa', visible: true },
    torso: { name: 'Torso', visible: true },
    arms: { name: 'Braccia', visible: true },
    legs: { name: 'Gambe', visible: true }
};

// Inizializzazione
function init() {
    // Creazione della scena
    scene = new THREE.Scene();
    scene.background = new THREE.Color(config.backgroundColor);

    // Creazione della camera
    camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
    camera.position.set(config.cameraPosition.x, config.cameraPosition.y, config.cameraPosition.z);

    // Creazione del renderer
    renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    document.getElementById('canvas-container').appendChild(renderer.domElement);

    // Aggiunta delle luci
    addLights();

    // Aggiunta del piano
    addFloor();

    // Inizializzazione dei controlli della camera
    initOrbitControls();

    // Inizializzazione del raycaster per la selezione degli oggetti
    raycaster = new THREE.Raycaster();
    mouse = new THREE.Vector2();

    // Gestione del ridimensionamento della finestra
    window.addEventListener('resize', onWindowResize, false);

    // Gestione del click del mouse
    renderer.domElement.addEventListener('click', onMouseClick, false);

    // Caricamento del modello 3D
    loadModel();

    // Inizializzazione dei controlli dell'interfaccia
    initControls();
    
    // Avvio del loop di rendering
    animate();
}

// Caricamento del modello 3D
function loadModel() {
    // Importazione del modello dettagliato
    const script = document.createElement('script');
    script.src = 'models/human_model.js';
    script.onload = function() {
        // Creazione del modello completo
        model = createCompleteHumanModel();
        scene.add(model);
        
        // Impostazione delle ombre
        model.traverse(function(child) {
            if (child.isMesh) {
                child.castShadow = true;
                child.receiveShadow = true;
            }
        });
    };
    script.onerror = function() {
        console.error('Errore nel caricamento del modello dettagliato. Utilizzo del modello placeholder.');
        createPlaceholderModel();
    };
    document.head.appendChild(script);
    
    // In una versione futura, potremmo caricare modelli GLTF reali
    // const loader = new THREE.GLTFLoader();
    // loader.load('models/gltf/human_anatomy.glb', function(gltf) {
    //     model = gltf.scene;
    //     scene.add(model);
    //     
    //     // Configurazione del modello
    //     model.traverse(function(child) {
    //         if (child.isMesh) {
    //             child.castShadow = true;
    //             child.receiveShadow = true;
    //         }
    //     });
    //     
    //     // Animazioni
    //     if (gltf.animations && gltf.animations.length) {
    //         mixer = new THREE.AnimationMixer(model);
    //         const action = mixer.clipAction(gltf.animations[0]);
    //         action.play();
    //     }
    // });
}

// Creazione di un modello placeholder semplice (fallback)
function createPlaceholderModel() {
    // Creazione di un gruppo per il modello
    model = new THREE.Group();
    scene.add(model);

    // Creazione di un modello umanoide semplice
    // Testa
    const headGeometry = new THREE.SphereGeometry(0.25, 32, 32);
    const headMaterial = new THREE.MeshLambertMaterial({ color: anatomySystems.skeletal.color });
    const head = new THREE.Mesh(headGeometry, headMaterial);
    head.position.y = 1.7;
    head.userData = { type: 'skeletal', region: 'head', name: 'Testa' };
    model.add(head);

    // Torso
    const torsoGeometry = new THREE.CylinderGeometry(0.3, 0.25, 0.6, 32);
    const torsoMaterial = new THREE.MeshLambertMaterial({ color: anatomySystems.muscular.color });
    const torso = new THREE.Mesh(torsoGeometry, torsoMaterial);
    torso.position.y = 1.25;
    torso.userData = { type: 'muscular', region: 'torso', name: 'Torso' };
    model.add(torso);

    // Bacino
    const pelvisGeometry = new THREE.CylinderGeometry(0.25, 0.2, 0.3, 32);
    const pelvisMaterial = new THREE.MeshLambertMaterial({ color: anatomySystems.skeletal.color });
    const pelvis = new THREE.Mesh(pelvisGeometry, pelvisMaterial);
    pelvis.position.y = 0.9;
    pelvis.userData = { type: 'skeletal', region: 'torso', name: 'Bacino' };
    model.add(pelvis);

    // Braccia
    const armGeometry = new THREE.CylinderGeometry(0.08, 0.06, 0.5, 32);
    const armMaterial = new THREE.MeshLambertMaterial({ color: anatomySystems.muscular.color });
    
    const leftArm = new THREE.Mesh(armGeometry, armMaterial);
    leftArm.position.set(-0.4, 1.25, 0);
    leftArm.rotation.z = Math.PI / 6;
    leftArm.userData = { type: 'muscular', region: 'arms', name: 'Braccio Sinistro' };
    model.add(leftArm);
    
    const rightArm = new THREE.Mesh(armGeometry, armMaterial);
    rightArm.position.set(0.4, 1.25, 0);
    rightArm.rotation.z = -Math.PI / 6;
    rightArm.userData = { type: 'muscular', region: 'arms', name: 'Braccio Destro' };
    model.add(rightArm);

    // Avambracci
    const forearmGeometry = new THREE.CylinderGeometry(0.06, 0.05, 0.5, 32);
    const forearmMaterial = new THREE.MeshLambertMaterial({ color: anatomySystems.muscular.color });
    
    const leftForearm = new THREE.Mesh(forearmGeometry, forearmMaterial);
    leftForearm.position.set(-0.6, 1.0, 0);
    leftForearm.rotation.z = Math.PI / 3;
    leftForearm.userData = { type: 'muscular', region: 'arms', name: 'Avambraccio Sinistro' };
    model.add(leftForearm);
    
    const rightForearm = new THREE.Mesh(forearmGeometry, forearmMaterial);
    rightForearm.position.set(0.6, 1.0, 0);
    rightForearm.rotation.z = -Math.PI / 3;
    rightForearm.userData = { type: 'muscular', region: 'arms', name: 'Avambraccio Destro' };
    model.add(rightForearm);

    // Gambe
    const legGeometry = new THREE.CylinderGeometry(0.1, 0.08, 0.5, 32);
    const legMaterial = new THREE.MeshLambertMaterial({ color: anatomySystems.muscular.color });
    
    const leftLeg = new THREE.Mesh(legGeometry, legMaterial);
    leftLeg.position.set(-0.15, 0.65, 0);
    leftLeg.userData = { type: 'muscular', region: 'legs', name: 'Coscia Sinistra' };
    model.add(leftLeg);
    
    const rightLeg = new THREE.Mesh(legGeometry, legMaterial);
    rightLeg.position.set(0.15, 0.65, 0);
    rightLeg.userData = { type: 'muscular', region: 'legs', name: 'Coscia Destra' };
    model.add(rightLeg);

    // Polpacci
    const calfGeometry = new THREE.CylinderGeometry(0.08, 0.06, 0.5, 32);
    const calfMaterial = new THREE.MeshLambertMaterial({ color: anatomySystems.muscular.color });
    
    const leftCalf = new THREE.Mesh(calfGeometry, calfMaterial);
    leftCalf.position.set(-0.15, 0.2, 0);
    leftCalf.userData = { type: 'muscular', region: 'legs', name: 'Polpaccio Sinistro' };
    model.add(leftCalf);
    
    const rightCalf = new THREE.Mesh(calfGeometry, calfMaterial);
    rightCalf.position.set(0.15, 0.2, 0);
    rightCalf.userData = { type: 'muscular', region: 'legs', name: 'Polpaccio Destro' };
    model.add(rightCalf);

    // Aggiunta di elementi del sistema cardiovascolare
    const heartGeometry = new THREE.SphereGeometry(0.1, 32, 32);
    const heartMaterial = new THREE.MeshLambertMaterial({ color: anatomySystems.cardiovascular.color });
    const heart = new THREE.Mesh(heartGeometry, heartMaterial);
    heart.position.set(0.1, 1.3, 0.1);
    heart.userData = { type: 'cardiovascular', region: 'torso', name: 'Cuore' };
    model.add(heart);

    // Aggiunta di elementi del sistema respiratorio
    const lungsGeometry = new THREE.SphereGeometry(0.12, 32, 32);
    const lungsMaterial = new THREE.MeshLambertMaterial({ color: anatomySystems.respiratory.color });
    
    const leftLung = new THREE.Mesh(lungsGeometry, lungsMaterial);
    leftLung.position.set(-0.15, 1.35, 0.05);
    leftLung.scale.set(0.7, 1, 0.7);
    leftLung.userData = { type: 'respiratory', region: 'torso', name: 'Polmone Sinistro' };
    model.add(leftLung);
    
    const rightLung = new THREE.Mesh(lungsGeometry, lungsMaterial);
    rightLung.position.set(0.15, 1.35, 0.05);
    rightLung.scale.set(0.7, 1, 0.7);
    rightLung.userData = { type: 'respiratory', region: 'torso', name: 'Polmone Destro' };
    model.add(rightLung);

    // Aggiunta di elementi del sistema nervoso
    const brainGeometry = new THREE.SphereGeometry(0.2, 32, 32);
    const brainMaterial = new THREE.MeshLambertMaterial({ color: anatomySystems.nervous.color });
    const brain = new THREE.Mesh(brainGeometry, brainMaterial);
    brain.position.set(0, 1.75, 0);
    brain.scale.set(0.9, 0.8, 0.9);
    brain.userData = { type: 'nervous', region: 'head', name: 'Cervello' };
    model.add(brain);

    // Aggiunta di elementi del sistema digerente
    const stomachGeometry = new THREE.SphereGeometry(0.12, 32, 32);
    const stomachMaterial = new THREE.MeshLambertMaterial({ color: anatomySystems.digestive.color });
    const stomach = new THREE.Mesh(stomachGeometry, stomachMaterial);
    stomach.position.set(0, 1.1, 0.1);
    stomach.scale.set(0.8, 1, 0.6);
    stomach.userData = { type: 'digestive', region: 'torso', name: 'Stomaco' };
    model.add(stomach);

    // Impostazione delle ombre
    model.traverse(function(child) {
        if (child.isMesh) {
            child.castShadow = true;
            child.receiveShadow = true;
        }
    });
}

// Inizializzazione dei controlli dell'interfaccia
function initControls() {
    // Gestione dei checkbox dei sistemi
    document.getElementById('skeletal-system').addEventListener('change', function() {
        toggleSystem('skeletal');
    });
    document.getElementById('muscular-system').addEventListener('change', function() {
        toggleSystem('muscular');
    });
    document.getElementById('nervous-system').addEventListener('change', function() {
        toggleSystem('nervous');
    });
    document.getElementById('cardiovascular-system').addEventListener('change', function() {
        toggleSystem('cardiovascular');
    });
    document.getElementById('respiratory-system').addEventListener('change', function() {
        toggleSystem('respiratory');
    });
    document.getElementById('digestive-system').addEventListener('change', function() {
        toggleSystem('digestive');
    });

    // Gestione dei checkbox delle regioni
    document.getElementById('head').addEventListener('change', function() {
        toggleRegion('head');
    });
    document.getElementById('torso').addEventListener('change', function() {
        toggleRegion('torso');
    });
    document.getElementById('arms').addEventListener('change', function() {
        toggleRegion('arms');
    });
    document.getElementById('legs').addEventListener('change', function() {
        toggleRegion('legs');
    });

    // Gestione delle opzioni di visualizzazione
    document.getElementById('wireframe').addEventListener('change', toggleWireframe);
    document.getElementById('transparent').addEventListener('change', toggleTransparency);
    document.getElementById('transparency-slider').addEventListener('input', updateTransparency);
    
    // Aggiungi pulsanti per viste predefinite
    document.getElementById('view-front').addEventListener('click', function() {
        setCameraPosition(0, 1.7, 3);
    });
    
    document.getElementById('view-back').addEventListener('click', function() {
        setCameraPosition(0, 1.7, -3);
    });
    
    document.getElementById('view-left').addEventListener('click', function() {
        setCameraPosition(-3, 1.7, 0);
    });
    
    document.getElementById('view-right').addEventListener('click', function() {
        setCameraPosition(3, 1.7, 0);
    });
    
    document.getElementById('view-top').addEventListener('click', function() {
        setCameraPosition(0, 5, 0);
    });
    
    document.getElementById('view-reset').addEventListener('click', function() {
        setCameraPosition(2, 2, 2);
    });
    
    // Aggiungi controlli di zoom con pulsanti
    document.getElementById('zoom-in').addEventListener('click', function() {
        zoomCamera(0.8); // Zoom in del 20%
    });
    
    document.getElementById('zoom-out').addEventListener('click', function() {
        zoomCamera(1.2); // Zoom out del 20%
    });
}

// Funzione per il reset della vista
function resetView() {
    controls.reset();
}

// Funzione per il cambio di vista
function changeView() {
    const view = document.getElementById('view-select').value;
    
    switch(view) {
        case 'front':
            camera.position.set(0, 1.7, 3);
            break;
        case 'back':
            camera.position.set(0, 1.7, -3);
            break;
        case 'left':
            camera.position.set(-3, 1.7, 0);
            break;
        case 'right':
            camera.position.set(3, 1.7, 0);
            break;
        case 'top':
            camera.position.set(0, 5, 0);
            break;
    }
    
    controls.update();
}

// Funzione per mostrare/nascondere un sistema anatomico
function toggleSystem(system) {
    const isVisible = document.getElementById(`${system}-system`).checked;
    anatomySystems[system].visible = isVisible;
    
    if (model) {
        // Cerca il gruppo del sistema specifico
        const systemGroup = model.getObjectByName(`${system}-system`);
        
        if (systemGroup) {
            // Se troviamo il gruppo, impostiamo la visibilità dell'intero gruppo
            systemGroup.visible = isVisible;
        } else {
            // Fallback: attraversa tutti i mesh e controlla il tipo
            model.traverse(function(child) {
                if (child.isMesh && child.userData && child.userData.type === system) {
                    child.visible = isVisible;
                }
            });
        }
        
        // Aggiorna il pannello informazioni se l'oggetto selezionato appartiene al sistema nascosto
        if (!isVisible && selectedObject && selectedObject.userData && selectedObject.userData.type === system) {
            selectedObject.material.emissive.setHex(0x000000);
            selectedObject = null;
            updateInfoPanel(null);
        }
    }
    
    // Aggiorna l'interfaccia utente per riflettere lo stato
    const systemLabel = document.querySelector(`label[for="${system}-system"]`);
    if (systemLabel) {
        if (isVisible) {
            systemLabel.classList.remove('disabled');
        } else {
            systemLabel.classList.add('disabled');
        }
    }
}

// Funzione per mostrare/nascondere una regione del corpo
function toggleRegion(region) {
    const isVisible = document.getElementById(region).checked;
    bodyRegions[region].visible = isVisible;
    
    if (model) {
        // Attraversa tutti i mesh e controlla la regione
        model.traverse(function(child) {
            if (child.isMesh && child.userData && child.userData.region === region) {
                // Verifica anche se il sistema a cui appartiene è visibile
                if (child.userData.type && anatomySystems[child.userData.type].visible) {
                    child.visible = isVisible;
                }
            }
        });
        
        // Aggiorna il pannello informazioni se l'oggetto selezionato appartiene alla regione nascosta
        if (!isVisible && selectedObject && selectedObject.userData && selectedObject.userData.region === region) {
            selectedObject.material.emissive.setHex(0x000000);
            selectedObject = null;
            updateInfoPanel(null);
        }
    }
    
    // Aggiorna l'interfaccia utente per riflettere lo stato
    const regionLabel = document.querySelector(`label[for="${region}"]`);
    if (regionLabel) {
        if (isVisible) {
            regionLabel.classList.remove('disabled');
        } else {
            regionLabel.classList.add('disabled');
        }
    }
}

// Funzione per attivare/disattivare la modalità wireframe
function toggleWireframe() {
    const wireframe = document.getElementById('wireframe').checked;
    
    if (model) {
        // Salva lo stato originale dei materiali se non è già stato fatto
        if (!model.userData.originalMaterials && wireframe) {
            model.userData.originalMaterials = {};
            model.traverse(function(child) {
                if (child.isMesh) {
                    // Salva una copia delle proprietà del materiale originale
                    model.userData.originalMaterials[child.id] = {
                        wireframe: child.material.wireframe
                    };
                }
            });
        }
        
        model.traverse(function(child) {
            if (child.isMesh) {
                child.material.wireframe = wireframe;
                
                // Aggiorna l'aspetto visivo in base alla modalità wireframe
                if (wireframe) {
                    // In modalità wireframe, aumentiamo la luminosità per vedere meglio le linee
                    child.material.emissiveIntensity = 0.3;
                    child.material.emissive.set(0x333333);
                } else if (model.userData.originalMaterials && model.userData.originalMaterials[child.id]) {
                    // Ripristina lo stato originale
                    child.material.emissiveIntensity = 0;
                    child.material.emissive.set(0x000000);
                    
                    // Se l'oggetto era selezionato, mantieni l'evidenziazione
                    if (selectedObject === child) {
                        child.material.emissive.setHex(0x333333);
                    }
                }
            }
        });
    }
    
    // Aggiorna l'interfaccia utente
    const wireframeLabel = document.querySelector('label[for="wireframe"]');
    if (wireframeLabel) {
        if (wireframe) {
            wireframeLabel.classList.add('active');
        } else {
            wireframeLabel.classList.remove('active');
        }
    }
}

// Funzione per attivare/disattivare la trasparenza
function toggleTransparency() {
    const transparent = document.getElementById('transparent').checked;
    const transparencySlider = document.getElementById('transparency-slider');
    
    if (model) {
        // Salva lo stato originale dei materiali se non è già stato fatto
        if (!model.userData.originalMaterials && transparent) {
            model.userData.originalMaterials = {};
            model.traverse(function(child) {
                if (child.isMesh) {
                    // Salva una copia delle proprietà del materiale originale
                    model.userData.originalMaterials[child.id] = {
                        transparent: child.material.transparent,
                        opacity: child.material.opacity
                    };
                }
            });
        }
        
        model.traverse(function(child) {
            if (child.isMesh) {
                child.material.transparent = transparent;
                if (transparent) {
                    child.material.opacity = parseFloat(transparencySlider.value);
                    child.material.needsUpdate = true;
                } else if (model.userData.originalMaterials && model.userData.originalMaterials[child.id]) {
                    // Ripristina lo stato originale
                    child.material.opacity = 1.0;
                    child.material.needsUpdate = true;
                }
            }
        });
    }
    
    // Abilita/disabilita lo slider della trasparenza
    transparencySlider.disabled = !transparent;
    
    // Aggiorna l'interfaccia utente
    const transparentLabel = document.querySelector('label[for="transparent"]');
    if (transparentLabel) {
        if (transparent) {
            transparentLabel.classList.add('active');
            document.querySelector('.slider-container').classList.add('active');
        } else {
            transparentLabel.classList.remove('active');
            document.querySelector('.slider-container').classList.remove('active');
        }
    }
}

// Funzione per aggiornare il livello di trasparenza
function updateTransparency() {
    const opacity = parseFloat(document.getElementById('transparency-slider').value);
    const transparencyValue = document.createElement('span');
    transparencyValue.textContent = Math.round(opacity * 100) + '%';
    
    if (model && document.getElementById('transparent').checked) {
        model.traverse(function(child) {
            if (child.isMesh) {
                child.material.opacity = opacity;
                child.material.needsUpdate = true;
            }
        });
    }
    
    // Aggiorna l'interfaccia utente per mostrare il valore corrente
    const sliderContainer = document.querySelector('.slider-container');
    const existingValue = sliderContainer.querySelector('.transparency-value');
    
    if (existingValue) {
        existingValue.textContent = Math.round(opacity * 100) + '%';
    } else {
        transparencyValue.className = 'transparency-value';
        sliderContainer.appendChild(transparencyValue);
    }
}

// Gestione del click del mouse per la selezione degli oggetti
function onMouseClick(event) {
    // Calcolo delle coordinate del mouse normalizzate
    mouse.x = (event.clientX / window.innerWidth) * 2 - 1;
    mouse.y = -(event.clientY / window.innerHeight) * 2 + 1;
    
    // Aggiornamento del raycaster
    raycaster.setFromCamera(mouse, camera);
    
    // Verifica delle intersezioni con gli oggetti della scena
    if (model) {
        const intersects = raycaster.intersectObjects(model.children, true);
        
        if (intersects.length > 0) {
            // Trova il primo oggetto con userData
            let selectedMesh = null;
            for (let i = 0; i < intersects.length; i++) {
                if (intersects[i].object.userData && 
                    intersects[i].object.userData.type && 
                    intersects[i].object.userData.name) {
                    selectedMesh = intersects[i].object;
                    break;
                }
            }
            
            if (selectedMesh) {
                // Deseleziona l'oggetto precedentemente selezionato
                if (selectedObject) {
                    selectedObject.material.emissive.setHex(0x000000);
                }
                
                // Seleziona il nuovo oggetto
                selectedObject = selectedMesh;
                selectedObject.material.emissive.setHex(0x333333);
                
                // Aggiorna il pannello informazioni
                updateInfoPanel(selectedObject.userData);
            }
        } else {
            // Nessun oggetto selezionato, deseleziona l'oggetto precedente
            if (selectedObject) {
                selectedObject.material.emissive.setHex(0x000000);
                selectedObject = null;
                
                // Aggiorna il pannello informazioni
                updateInfoPanel(null);
            }
        }
    }
}

// Aggiornamento del pannello informazioni
function updateInfoPanel(data) {
    const infoPanel = document.getElementById('info-panel');
    
    if (data) {
        // Costruisci il contenuto del pannello informazioni
        let content = `<h2>${data.name}</h2>`;
        
        // Aggiungi informazioni sul sistema anatomico
        if (data.type && anatomySystems[data.type]) {
            content += `<p><strong>Sistema:</strong> ${anatomySystems[data.type].name}</p>`;
        }
        
        // Aggiungi informazioni sulla regione
        if (data.region && bodyRegions[data.region]) {
            content += `<p><strong>Regione:</strong> ${bodyRegions[data.region].name}</p>`;
        }
        
        // Aggiungi descrizione specifica per ogni parte
        switch (data.name) {
            case 'Testa':
                content += `<p>La testa contiene il cervello, gli organi sensoriali principali e l'inizio del sistema digestivo e respiratorio.</p>`;
                break;
            case 'Cervello':
                content += `<p>Il cervello è l'organo principale del sistema nervoso centrale, responsabile del controllo di tutte le funzioni corporee e dell'elaborazione delle informazioni.</p>`;
                break;
            case 'Cuore':
                content += `<p>Il cuore è un organo muscolare cavo che pompa il sangue attraverso il sistema circolatorio, fornendo ossigeno e nutrienti a tutte le cellule del corpo.</p>`;
                break;
            case 'Polmone Sinistro':
            case 'Polmone Destro':
                content += `<p>I polmoni sono gli organi principali del sistema respiratorio, responsabili dello scambio di ossigeno e anidride carbonica con il sangue.</p>`;
                break;
            case 'Stomaco':
                content += `<p>Lo stomaco è un organo del sistema digerente che svolge un ruolo importante nella digestione, secernendo acidi e enzimi che scompongono il cibo.</p>`;
                break;
            default:
                content += `<p>Parte anatomica del corpo umano.</p>`;
        }
        
        infoPanel.innerHTML = content;
        infoPanel.classList.add('active');
    } else {
        // Nessun oggetto selezionato, mostra un messaggio predefinito
        infoPanel.innerHTML = `
            <h2>Visualizzatore Anatomico 3D</h2>
            <p>Seleziona una parte del corpo per visualizzare informazioni dettagliate.</p>
            <p>Utilizza i controlli a sinistra per filtrare i sistemi anatomici e le regioni del corpo.</p>
        `;
        infoPanel.classList.remove('active');
    }
}

// Aggiunta delle luci alla scena
function addLights() {
    // Luce ambientale
    const ambientLight = new THREE.AmbientLight(config.ambientLightColor, config.ambientLightIntensity);
    scene.add(ambientLight);
    
    // Luce direzionale principale
    const mainLight = new THREE.DirectionalLight(config.directionalLightColor, config.directionalLightIntensity);
    mainLight.position.set(5, 5, 5);
    mainLight.castShadow = true;
    
    // Configurazione delle ombre
    mainLight.shadow.mapSize.width = 2048;
    mainLight.shadow.mapSize.height = 2048;
    mainLight.shadow.camera.near = 0.5;
    mainLight.shadow.camera.far = 20;
    mainLight.shadow.camera.left = -5;
    mainLight.shadow.camera.right = 5;
    mainLight.shadow.camera.top = 5;
    mainLight.shadow.camera.bottom = -5;
    
    scene.add(mainLight);
    
    // Luce direzionale di riempimento
    const fillLight = new THREE.DirectionalLight(0xffffff, 0.3);
    fillLight.position.set(-5, 3, -5);
    scene.add(fillLight);
}

// Aggiunta del piano
function addFloor() {
    const floorGeometry = new THREE.CircleGeometry(5, 32);
    const floorMaterial = new THREE.MeshStandardMaterial({ 
        color: 0xeeeeee,
        roughness: 0.8,
        metalness: 0.2
    });
    const floor = new THREE.Mesh(floorGeometry, floorMaterial);
    floor.rotation.x = -Math.PI / 2;
    floor.position.y = 0;
    floor.receiveShadow = true;
    scene.add(floor);
}

// Gestione del ridimensionamento della finestra
function onWindowResize() {
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
}

// Funzione di animazione
function animate() {
    requestAnimationFrame(animate);
    
    // Aggiornamento dei controlli
    controls.update();
    
    // Aggiornamento delle animazioni
    if (mixer) {
        mixer.update(clock.getDelta());
    }
    
    // Rendering della scena
    renderer.render(scene, camera);
}

// Funzione per inizializzare i controlli di rotazione e zoom
function initOrbitControls() {
    controls = new THREE.OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.25;
    controls.screenSpacePanning = false;
    controls.maxPolarAngle = Math.PI;
    controls.minDistance = 1;
    controls.maxDistance = 10;
    controls.target.set(0, 1, 0);
    
    // Aggiungi eventi per aggiornare l'interfaccia durante la rotazione/zoom
    controls.addEventListener('change', function() {
        // Aggiorna il pannello informativo con l'angolo di vista corrente
        const cameraPosition = document.getElementById('camera-position');
        if (cameraPosition) {
            const position = camera.position.clone().round();
            cameraPosition.textContent = `Vista: X:${position.x} Y:${position.y} Z:${position.z}`;
        }
        
        // Aggiorna l'indicatore di zoom
        const zoomLevel = document.getElementById('zoom-level');
        if (zoomLevel) {
            // Calcola il livello di zoom in percentuale (inverso della distanza)
            const distance = camera.position.distanceTo(controls.target);
            const zoomPercentage = Math.round(100 * (1 - (distance - controls.minDistance) / (controls.maxDistance - controls.minDistance)));
            zoomLevel.textContent = `Zoom: ${zoomPercentage}%`;
        }
    });
}

// Funzione per impostare la posizione della camera
function setCameraPosition(x, y, z) {
    // Animazione fluida della transizione
    const startPosition = camera.position.clone();
    const endPosition = new THREE.Vector3(x, y, z);
    const duration = 1000; // millisecondi
    const startTime = Date.now();
    
    function animate() {
        const elapsedTime = Date.now() - startTime;
        const progress = Math.min(elapsedTime / duration, 1);
        
        // Interpolazione della posizione
        camera.position.lerpVectors(startPosition, endPosition, progress);
        
        // Guarda sempre verso il centro del modello
        camera.lookAt(0, 1, 0);
        controls.update();
        
        if (progress < 1) {
            requestAnimationFrame(animate);
        }
    }
    
    animate();
}

// Funzione per lo zoom della camera
function zoomCamera(factor) {
    // Calcola la nuova distanza dal target
    const direction = camera.position.clone().sub(controls.target);
    const distance = direction.length() * factor;
    
    // Limita la distanza ai valori min e max
    const clampedDistance = Math.max(
        controls.minDistance,
        Math.min(controls.maxDistance, distance)
    );
    
    // Normalizza la direzione e imposta la nuova posizione
    direction.normalize().multiplyScalar(clampedDistance);
    camera.position.copy(controls.target).add(direction);
    
    controls.update();
}

// Inizializzazione dell'applicazione
window.addEventListener('DOMContentLoaded', init);
